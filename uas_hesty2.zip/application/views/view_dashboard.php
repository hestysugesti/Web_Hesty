<div class="container">
<a href="<?php echo base_url('Myadmin/tambahdata')?>" class="btn btn-primary" style="margin-bottom: 10px" > + Tambah Data</a>
<br>
</div>
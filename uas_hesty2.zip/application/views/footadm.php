<br><br>
<h1 align="center">Ini Footer</h1>

</body>
</html>

<script>
    $().click(function(){
        var id=$(this).data('id');
        $('#modalDelete').attr(id);
    })
</script>
<nav class="navbar navbar-inverse">
			<div class="container-fluid">
				<div class="navbar-header">
					<a class="navbar-brand" href="#">STT Bandung</a>
				</div>
				<ul class="nav navbar-nav">
					<li class="active"><a href="#">Admin</a></li>
					<li class="dropdown">
						<ul class="nav navbar-nav">
							<li class="active"><a href="#">Mahasiswa</a></li>
							<li class="active">
								<a href="<?php echo site_url("Login/logout"); ?>">Logout</a>
							</li>
						</ul>
					</li>
				</ul>
			</div>
		</nav>